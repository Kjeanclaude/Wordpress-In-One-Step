<?php  
$hostnamejc = $_GET['host'];
$userjc = $_GET['user'];  
$passwordjc = $_GET['pass'];
$bdjc = $_GET['bd'];
$lang = $_GET['lang'];

/* function ConfirmationSubmit2()
{
  var x = document.getElementById("bouton_valider");
  x.addEventListener("submit", chargement, false);
}
window.onsubmit=ConfirmationSubmit2; */

/* function ConfirmationSubmit()
	{
			
if ((return confirm('Si la BASE DE DONNEES SAISIE existe déjà, elle sera vidée ! Dans le cas contraire, elle sera créée. Voulez-vous vraiment continuer ?');)=="false"){document.getElementById('chargement').style.visibility='hidden';} else {chargement();}
		
	}
 */
 ?>
<script language="\javascript\" type="text/javascript">

function language_conv(){
   
   var liste, texte;
	texte = "";
	liste = document.getElementById("Langue");
	texte = liste.options[liste.selectedIndex].text;

   if(texte !="English")
	{
		/*alert("Je suis Français !");*/
		document.getElementById("libelle_traitement").innerHTML="TRAITEMENT EN COURS ... VEUILLEZ PATIENTER !";
		document.getElementById('libelle_etape').innerHTML = "ETAPE UNIQUE D&rsquo;INSTALLATION: <br />PARAMETRAGE DE LA BASE DE DONNEES"; 
		document.getElementById('libelle_langue').innerHTML = "Langue d&rsquo;installation :"; 
		document.getElementById('libelle_bd').innerHTML = "Nom de la base donn&eacute;es :"; 
		document.getElementById('libelle_user').innerHTML = "Utilisateur MySQL :"; 
		document.getElementById('libelle_pass').innerHTML = "Mot de passe MySQL :"; 
		document.getElementById('libelle_host').innerHTML = "Nom de l&#8217;h&ocirc;te MySQL :"; 
		document.getElementById("bouton_valider").value="VALIDER";
		document.getElementById("libelle_alerte").innerHTML="TRAITEMENT EN COURS ... VEUILLEZ PATIENTER";

	}
	else
	{
	    /*alert("Je suis anglais !");*/
		document.getElementById("libelle_traitement").innerHTML="PLEASE WAIT DURING PROCESS !";
		document.getElementById('libelle_etape').innerHTML = "INSTALLATION IN ONE STEP : <br />DATABASE SETUP"; 
		document.getElementById('libelle_langue').innerHTML = "Installation language :"; 
		document.getElementById('libelle_bd').innerHTML = "Database name :"; 
		document.getElementById('libelle_user').innerHTML = "MySQL username :"; 
		document.getElementById('libelle_pass').innerHTML = "MySQL password :"; 
		document.getElementById('libelle_host').innerHTML = "MySQL host :"; 
		document.getElementById("bouton_valider").value="SUBMIT";
	}

	//window.parent.document.refresh();
} 
//var timer=setInterval("language_conv()", 1000);





function chargement(){
   document.getElementById('chargement').style.visibility='visible';
   document.getElementById('site').style.visibility='visible';
}




function cache_chargement(){
   document.getElementById('chargement').style.visibility='hidden';
   document.getElementById('site').style.visibility='visible';
   form1.mysql_db.focus();

}

function chargement_alerte(){
   document.getElementById('chargement_alerte').style.visibility='visible';
   document.getElementById('site_alerte').style.visibility='visible';
}




function cache_chargement_alerte(){
   document.getElementById('chargement_alerte').style.visibility='hidden';
   document.getElementById('site_alerte').style.visibility='visible';
   form1.mysql_db.focus();

}

/* 
function ConfirmationSubmit()
	{
		if (confirm('Si la BASE DE DONNEES SAISIE existe déjà, elle sera vidée ! Dans le cas contraire, elle sera créée. Voulez-vous vraiment continuer ?'))
		{chargement();
			return true;
		}
		else
		{cache_chargement();
			return false;
		}		
		
	} */


/* function ConfirmationBootstrap3()
	{	
        BootstrapDialog.confirm('Si la BASE DE DONNEES SAISIE existe déjà, elle sera vidée ! Dans le cas contraire, elle sera créée. Voulez-vous vraiment continuer ?', function(result){
            if(result) {
				
				
				chargement();
				
            }else {
				
				window.stop();
				cache_chargement();
					
            };
		});
		
	}
	 */

	
function ConfirmationBootstrap4()
	{	  
		
			var liste, texte;
			liste = document.getElementById("Langue");
			texte = liste.options[liste.selectedIndex].text;
			
			
			
	   if(texte !="English")
		{
			/*alert("Je suis Français !");*/
				
				BootstrapDialog.show({
				
				message: 'Si la BASE DE DONNEES SAISIE existe d&eacute;j&agrave;, elle sera vid&eacute;e ! Dans le cas contraire, elle sera cr&eacute;&eacute;e. Voulez-vous vraiment continuer ?',
				//type: BootstrapDialog.TYPE_WARNING,
				type: BootstrapDialog.TYPE_DANGER,
				title: 'INFOS WORDPRESS (!) :',
				closable: false,
				buttons: [{
					
					label: 'ANNULER',
					cssClass: 'btn-warning',
					action: function(dialogRef){
						dialogRef.setClosable(false);	
						
						dialogRef.close();
							
						window.stop();
						
						close();
						cache_chargement();
						
						window.location.reload();
						return false;
						
						
						
					}
				}, {
					label: 'VALIDER',
					cssClass: 'btn-success',
					action: function(dialogRef){
						dialogRef.setClosable(true);
						chargement();
						
						dialogRef.close();
						document.getElementById('bouton_valider').submit();
						return true;
					}
				}]
			});
			
		}
		else
		{
			/*alert("Je suis anglais !");*/
				BootstrapDialog.show({
				message: 'If the DATABASE ENTRY already exists, it will be emptied! Otherwise, it will be created. Do you really want to continue?',
				title: 'WORDPRESS INFO (!) :',
				type: BootstrapDialog.TYPE_DANGER,
				closable: false,
				buttons: [{
					
					label: 'CANCEL',
					cssClass: 'btn-warning',
					action: function(dialogRef){
						/* dialogRef.setClosable(false);	
						window.stop();
						//event.returnValue = false;
						return false;
						cache_chargement();
						window.location.reload();
						dialogRef.close(); */
						dialogRef.setClosable(false);	
						
						dialogRef.close();
							
						window.stop();
						
						close();
						cache_chargement();
						
						window.location.reload();
						return false;
						
											}
				}, {
					label: 'SUBMIT',
					cssClass: 'btn-success',
					action: function(dialogRef){
						dialogRef.setClosable(true);
						chargement();
						dialogRef.close();
						return true;
					}
				}]
			});
		}
				/* document.getElementById('form1').onsubmit = ConfirmationBootstrap4() {
				return false;
				} */
	}


function Optionclic(){
    
	//var liste, texte;
	var texte = "";
	var db, pass, user, host, lang = "";
	
	
	 //= "<?php echo $_POST["mysql_db"]; ?>" ;//"testjc";
	host="<?php echo $hostnamejc; ?>"; //= $_GET['host'];
	user="<?php echo $userjc; ?>"; //= $_GET['user'];  
	pass="<?php echo $passwordjc; ?>"; //= $_GET['pass'];
	db="<?php echo $bdjc; ?>"; //= $_GET['bd'];
	lang="<?php echo $lang; ?>"; //= $_GET['bd'];
	
	if (lang=="") 
	{
		texte = "<?php echo $_POST["Langue"]; ?>" ;  
	}
     else
	 {
		texte = "<?php echo $lang; ?>" ; //"English"; 
	 };//"English";
	
	//liste = document.getElementById("Langue");
	//texte = $Langue;//liste.options[liste.selectedIndex].text; 
	//alert(texte);
	
   if(texte !="English")
	{
		/*alert("Je suis Français !");*/
		
		document.getElementById("libelle_traitement").innerHTML="TRAITEMENT EN COURS ... VEUILLEZ PATIENTER !";
		document.getElementById('libelle_etape').innerHTML = "ETAPE UNIQUE D&rsquo;INSTALLATION: <br />PARAMETRAGE DE LA BASE DE DONNEES"; 
		document.getElementById('libelle_langue').innerHTML = "Langue d&rsquo;installation :"; 
		document.getElementById('libelle_bd').innerHTML = "Nom de la base donn&eacute;es :"; 
		document.getElementById('libelle_user').innerHTML = "Utilisateur MySQL :"; 
		document.getElementById('libelle_pass').innerHTML = "Mot de passe MySQL :"; 
		document.getElementById('libelle_host').innerHTML = "Nom de l&#8217;h&ocirc;te MySQL :"; 
		document.getElementById("bouton_valider").value="VALIDER";
		document.getElemebtById("Langue").value = "Français";
		/*document.getElemebtById("mysql_db").value = "NOUVEAU";
		document.getElementById("bouton_valider").value="NOUVEAU";
		 document.forms['form1'].elements['mysql_db'].value = db;
		document.forms["form1"].elements["mysql_db"].value="NOUVEAU";
		document.getElementsByName("mysql_db")[0].value ="NOUVEAU";
		$("mysql_db").attr("value", "trois");
		this.form.mysql_db.value="db";
		$('#mysql_db').val("tfg"); */

	}
	else
	{
	    /*alert("Je suis anglais !");*/
		
		document.getElementById("libelle_traitement").innerHTML="PLEASE WAIT DURING PROCESS !";
		document.getElementById("libelle_etape").innerHTML = "INSTALLATION IN ONE STEP : <br />DATABASE SETUP"; 
		document.getElementById("libelle_langue").innerHTML = "Installation language :"; 
		document.getElementById("libelle_bd").innerHTML = "Database name :"; 
		document.getElementById("libelle_user").innerHTML = "MySQL username :"; 
		document.getElementById("libelle_pass").innerHTML = "MySQL password :"; 
		document.getElementById('libelle_host').innerHTML = "MySQL host :"; 
		document.getElementById("bouton_valider").value="SUBMIT";
		//document.getElemebtById("Langue").value = "English";
		//document.getElemebtById("Langue").selectedIndex = 1;
		//document.getElementById(Langue).options[0].text="English"; 
		//document.getElementsById("Langue").selected = "English";
		document.forms['form1'].elements['Langue'].selectedIndex = 1;
		//document.forms['form1'].elements['mysql_db'].value = "db";
		//document.getElemebtById("mysql_db").innerHTML = "db";
	}
	
	
}
	
function validateForm(form)
{
		
	if(form.mysql_db.value=="")
	{
		alert("Champ obligatoire : Veuillez renseigner le nom de la base de données MySQL!");
		form.mysql_db.focus();
		return false;
	}
	
	
	if(form.mysql_user.value=="")
	{
		alert("Champ obligatoire : Veuillez renseigner le nom de l'utilisateur MySQL!");
		form.mysql_user.focus();
		return false;
	}
	
	if(form.mysql_host.value=="")
	{
		alert("Champ obligatoire : Veuillez renseigner le nom d'hôte MySQL!");
		form.mysql_host.focus();
		return false;
	}
	
	
return true;
	
}


   // function RefreshIframe(){
   // document.getElementById('Langue').src = 'http://localhost/wordpresseng/wordpress-install.php';
	//language_conv();
   // }
   // setInterval("RefreshIframe();",5000); // 5 secondes


</script>

<?php 
//INSERTION DES DONNEES DU FORMULAIRE DANS LA BASE DE DONNEES

//setlocale (LC_ALL, 'fr_FR');
//$mavariablePHP = $_GET['mavariablePHP']; 


if (sizeof($_POST) > 0) 
{
	session_start();
	$_SESSION['old_post'] = $_POST;
    $frm = $_POST;
    $erreurs = array();
    $msg = array();

// TRAITEMENT DES DONNEES LUES
	$Langue="";

// On récupère les champs du formulaire, et on arrange leur mise en forme 

	if (isset($_POST["Langue"])) $_POST["Langue"]=trim(stripslashes($_POST["Langue"]));
	$Langue=htmlentities($_POST['Langue'], ENT_QUOTES,'UTF-8');

	if (isset($_POST["mysql_db"])) $_POST["mysql_db"]=trim(stripslashes($_POST["mysql_db"]));
	$mysql_db=htmlentities($_POST['mysql_db'], ENT_QUOTES,'UTF-8');
	
	if (isset($_POST["mysql_user"])) $_POST["mysql_user"]=trim(stripslashes($_POST["mysql_user"]));
	$mysql_user=htmlentities($_POST['mysql_user'], ENT_QUOTES,'UTF-8');
	
	if (isset($_POST["mysql_pwd"])) $_POST["mysql_pwd"]=trim(stripslashes($_POST["mysql_pwd"]));
	$mysql_pwd=htmlentities($_POST['mysql_pwd'], ENT_QUOTES,'UTF-8');
	
	if (isset($_POST["mysql_host"])) $_POST["mysql_host"]=trim(stripslashes($_POST["mysql_host"]));
	$mysql_host=htmlentities($_POST['mysql_host'], ENT_QUOTES,'UTF-8');
	
			
			if ($Langue != "English")
			{
				$filename = 'wordpressfr.sql';
			}
			else
			{
				$filename = 'wordpresseng.sql';
			};
	
	///////// ATTENTE ////////////
    sleep(15); // attends 15 secondes

////  DESCRIPTION DES FONCTIONS
	
function strToNoAccent($var) {
		$var = str_replace(
			array(
				'à', 'â', 'ä', 'á', 'ã', 'å',
				'î', 'ï', 'ì', 'í', 
				'ô', 'ö', 'ò', 'ó', 'õ', 'ø', 
				'ù', 'û', 'ü', 'ú', 
				'é', 'è', 'ê', 'ë', 
				'ç', 'ÿ', 'ñ',
				'À', 'Â', 'Ä', 'Á', 'Ã', 'Å',
				'Î', 'Ï', 'Ì', 'Í', 
				'Ô', 'Ö', 'Ò', 'Ó', 'Õ', 'Ø', 
				'Ù', 'Û', 'Ü', 'Ú', 
				'É', 'È', 'Ê', 'Ë', 
				'Ç', 'Ÿ', 'Ñ', 
			),
			array(
				'a', 'a', 'a', 'a', 'a', 'a', 
				'i', 'i', 'i', 'i', 
				'o', 'o', 'o', 'o', 'o', 'o', 
				'u', 'u', 'u', 'u', 
				'e', 'e', 'e', 'e', 
				'c', 'y', 'n', 
				'A', 'A', 'A', 'A', 'A', 'A', 
				'I', 'I', 'I', 'I', 
				'O', 'O', 'O', 'O', 'O', 'O', 
				'U', 'U', 'U', 'U', 
				'E', 'E', 'E', 'E', 
				'C', 'Y', 'N', 
			),$var);
		return $var;
	}




function MajusculeSansAccent($var) { 
			$search =  'ÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÒÓÔÕÖÙÚÛÜÝàáâãäåçèéêëìíîïðòóôõöùúûüýÿ'; 
			$replace = 'AAAAAACEEEEIIIIOOOOOUUUUYAAAAAACEEEEIIIIOOOOOOUUUUYY';
			return htmlentities(strtr(strtoupper($var),$search,$replace), ENT_QUOTES,'UTF-8');
			//htmlentities($AutreTypeProduit, ENT_QUOTES,'UTF-8')
			}	
			
function removeaccents2($defenseur){    $defenseur= strtr($defenseur,  "ÀÁÂÃÄÅàáâãäåÒÓÔÕÖØòóôõöøÈÉÊËèéêëÇçÌÍÎÏìíîïÙÚÛÜùúûüÿÑñ",  "aaaaaaaaaaaaooooooooooooeeeeeeeecciiiiiiiiuuuuuuuuynn" );    return $defenseur;    } 	
	
	

function date_ajout_jour($DATE_Depart,$Nbre_de_jours)
{	
	//date de départ : 01 avril 2013
$dateDepart = $DATE_Depart;//'01-04-2013';

//durée à rajouter : 6 jours;
$duree = $Nbre_de_jours;

//la première étape est de transformer cette date en timestamp
$dateDepartTimestamp = strtotime($dateDepart);

//on calcule la date de fin
$dateFin         = date('d-m-Y', strtotime('+'.$duree.'day', $dateDepartTimestamp ));

return $dateFin ;

}


function getDayInLetter($date){
	$timestamp = strtotime($date);
    $day = date('l', $timestamp);
	return $day;
}

function getDayInteger($date){
	$timestamp = strtotime($date);
    $day = date('d', $timestamp);
	return $day;
}

function getMonthInteger($date){
	$timestamp = strtotime($date);
    $month = date('m', $timestamp);
	return $month;
}

function getYearInteger($date){
	$timestamp = strtotime($date);
    $year = date('Y', $timestamp);
	return $year;
}


function getDateInFrench($date_rendez_vous){
	
	// TRAITEMENT DATE RENDEZ-VOUS VERS DATE EN FRANCAIS
	// Stockage des noms de jours et mois en français
	$jour = array("Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi");
	$mois = array("","Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre");
			// Initialisation date de naissance
			//$naissance = mktime(0, 0, 0, 5, 10, 1948);
			$date_tester = mktime(0, 0, 0, getMonthInteger($date_rendez_vous), getDayInteger($date_rendez_vous), getYearInteger($date_rendez_vous));
					// Date de RDV en français
					$date_rendez_vous_fr = date("d", $date_tester)." ".$mois[date("n", $date_tester)]." ".date("Y", $date_tester);
					// Affichage
					//echo 'Le webmestre est né le '.$date_rendez_vous_fr.', c\'était donc un <b>'.$jour[date("w", $date_tester)].'</b>';
					
					$date_rendez_vous_fr= $jour[date("w", $date_tester)]." ".$date_rendez_vous_fr;
				
		    // FIN TRAITEMENT DATE RENDEZ-VOUS VERS DATE EN FRANCAIS
	$date_rendez_vous_fr=strtoupper($date_rendez_vous_fr);
	
	return $date_rendez_vous_fr;
}





function isFerie($date){
	$lesFeries = getHolidays(getYearInteger($date));
	//echo "Annee  ".getYearInteger($date)." - ";
	//echo "Mois  ".getMonthInteger($date)." - ";
	//echo "Jour  ".getDayInteger($date)." - ";
	$resultat=0;
	$date_tester = mktime(0, 0, 0, getMonthInteger($date), getDayInteger($date), getYearInteger($date));
	
	//echo "taille feries  ".sizeof($lesFeries)." - ";
	//echo "date a tester  ".$date_tester." - ";
	
	for($i=0; $i < sizeof($lesFeries); $i++)
	{
		//echo "date ferie  ".$lesFeries[$i]." -> ";
		if($date_tester == $lesFeries[$i]){
		$resultat=1; 
		}
	}
	return $resultat;
}


function getHolidays($year = null)
{
  if ($year === null)
  {
    $year = intval(date('Y'));
  }
 
  $easterDate  = easter_date($year);
  $easterDay   = date('j', $easterDate);
  $easterMonth = date('n', $easterDate);
  $easterYear   = date('Y', $easterDate);
 
  $holidays = array(
    // Dates fixes
    mktime(0, 0, 0, 1,  1,  $year),  // 1er janvier
    mktime(0, 0, 0, 5,  1,  $year),  // Fête du travail
    mktime(0, 0, 0, 8,  7, $year),  // Fête nationale
    mktime(0, 0, 0, 8,  15, $year),  // Assomption
    mktime(0, 0, 0, 11, 1,  $year),  // Toussaint
    mktime(0, 0, 0, 11,  15,  $year),  // Fete de la paix
    mktime(0, 0, 0, 12, 25, $year),  // Noel
	
	// Dates variables
    mktime(0, 0, 0, $easterMonth, $easterDay + 2,  $easterYear),
    mktime(0, 0, 0, $easterMonth, $easterDay + 40, $easterYear),
    mktime(0, 0, 0, $easterMonth, $easterDay + 50, $easterYear),
  );
 
  sort($holidays);
 
  return $holidays;
}



// FONCTION VERIF_CREATION $mysql_db $mysql_user  $mysql_pwd $mysql_host
function verif_creation_bd_mysql($mysql_db, $mysql_user,  $mysql_pwd, $mysql_host, $Langue)
{	
		//CREER LA BASE DE DONNEES SI ELLE N'EXISTE PAS DEJA	
		$hostname = "$mysql_host";
		//echo $hostname;    
    	$user = $mysql_user;
		//echo $user;    
    	$password = $mysql_pwd;
		//echo $password;    
    	$bd = $mysql_db;
		//echo $bd;   
		$lang = $Langue;
        $exist = "FALSE";
        $rq = "show databases";
		
		
		$conx="?bd=$mysql_db&user=$mysql_user&pass=$password&host=$hostname&lang=$lang";
		
		//echo $hostname;  
		$url = $_SERVER['SERVER_NAME'] . $_SERVER['PHP_SELF'];
		$url_list = explode('/', $url);
		$url_dossier = $url_list[1]; // affiche: premierDossier
		
		
		$url_finale='/'.$url_dossier.'/wordpress-install.php';
		$url_finale='http://' .$_SERVER['SERVER_NAME'] .$url_finale;
		//header('Location: '.$url_finale);
		
		if ($Langue != "English")
			{
				$mot_retour = "RETOUR AU FORMULAIRE...";
			}
			else
			{
				$mot_retour = "RETURN TO THE FORM...";
			};

		$url_finale=$url_finale.$conx;
		$retour="<p style=\"text-align:center\"><a href=$url_finale >"."<span style=\"color:blue\">".$mot_retour."</span>"."</a></p>";
		//echo "<script type='text/javascript'>document.location.replace('$url_finale');</script>";
		  
		//echo '<div class="erreur">'.$err.'</div>'; 
        if ($conn = mysql_pconnect($hostname, $user, $password))
		{
			// CONNEXION EFFECTUEE, EXECUTER LA REQUETE
			
					if ($mysql_result = mysql_query($rq, $conn))
					{
						//REQUETE OK, CREER LA BD SI ELLE N'EXISTE PAS  
							while($row = mysql_fetch_array($mysql_result))
							{
								IF (strcmp ("$bd",$row["0"]) == 0){
								 $exist="TRUE";}
								  
								 else {
								$sql = "CREATE DATABASE IF NOT EXISTS ".$bd;
								mysql_query($sql, $conn) or die (mysql_error());
								$exist="TRUE";     
								  }
							}
					 
					 
						// S'ASSURER DE VIDER LA BASE DE DONNEES SI ELLE EXISTE DEJA         
						  if ($exist=="TRUE")
						     {
										//$db = mysqli_connect('localhost','root','','envi_bd');
									$db = mysqli_connect($mysql_host,$mysql_user,$mysql_pwd,$mysql_db); 
									if (! $db) 
									{
										if ($Langue != "English")
										{
											exit('Echec de la connexion lors du vidage de la base de données.');
											$msg3 = "ERREUR LORS DU VIDAGE DE LA BASE DE DONNEES \r\n VERIFIEZ VOS DROITS SUR LA BASE DE DONNEES !\r\n ".$retour ; 
											// or die(mysql_error()."Affichage des BD");
											return $msg3;
											exit;
										}
										else
										{
											exit('Failed to connect when emptying the database.');
											$msg3 = "ERROR WHEN DROPPING DATABASE \ r \ n CHECK YOUR RIGHTS ON THE DATABASE !\r\n ".$retour; 
											// or die(mysql_error()."Affichage des BD");
											return $msg3;
											exit;
										};
										
										
										
									}
									else
									{
										
										// ON VIDE LA BASE DE DONNEES
										// echo "resultat ".$res;
										$sqlDB_DROP = "DROP DATABASE $mysql_db"; 
										$okDB_DROP = mysqli_query($db,$sqlDB_DROP);
										
										$sqlDB_CREATE = "CREATE DATABASE $mysql_db"; 
										$okDB_CREATE = mysqli_query($db,$sqlDB_CREATE);
									}
							  }
								
									
					}// SI ERREUR EXECUTION REQUETE
					else
					{
						if ($Langue != "English")
							{
								$msg2 = "ERREUR LORS DE L'EXECUTION DE LA REQUETE, \r\n PROBLEME D'AFFICHAGE DE LA LISTE DES BASE DE DONNEES !".$retour; 
								// or die(mysql_error()."Affichage des BD");
								return $msg2;
								exit;
							}
							else
							{
								$msg2 = "ERROR WHEN EXECUTING THE REQUEST, \r\n THERE IS A PROBLEM TO DISPLAY THE DATABASES LIST !".$retour; 
								// or die(mysql_error()."Affichage des BD");
								return $msg2;
								exit;
							};
						
					}
				   		  	
			
		} // SI ERREUR LORS DE LA CONNEXION
		else
		{
			
			if ($Langue != "English")
				{
					$msg = "ERREUR LORS DE LA CONNEXION A LA BASE DE DONNEES \r\n NOM D'UTILISATEUR ET/OU MOT DE PASSE ET/OU NOM D'HOTE ERRONNE !".$retour; 
					//echo '<div id="message_bar">'.nl2br("<span style=\"color:red\">".$msg."</span>").'</div>'; 
					$err=true;
					return $msg;
					exit;
				}
				else
				{
					$msg = "ERROR WHEN CONNECTING TO DATABASE, \r\n USERNAME AND/OR PASSWORD AND/OR HOST NAME WRONGLY ENTERED !".$retour; 
					//echo '<div id="message_bar">'.nl2br("<span style=\"color:red\">".$msg."</span>").'</div>'; 
					$err=true;
					return $msg;
					exit;
				};
			
			
			/* echo '<script type="text/javascript">'
				 .'document.getElementById("message_bar").innerHTML= '.$msg.';'
				 .'form.mysql_user.focus();'
        		 .'return false;' */
			/*  . 'alert("Erreur : '.$erreur.'");' */
			    /*  . '</script>'; */
		}// or die('<div id="message_bar">'.nl2br("<span style=\"color:red\">".$msg."</span>").'</div>') ;// die(mysql_error()."Connexion à la BD");
         
      
	  	  
} // FIN FONCTION VERIF_CREATION



// FONCTION IMPORT PACKAGE BD $mysql_db $mysql_user  $mysql_pwd $mysql_host 
function import_package_bd_mysql($mysql_db, $mysql_user,  $mysql_pwd, $mysql_host, $Langue)
{	
		//CREER LA BASE DE DONNEES SI ELLE N'EXISTE PAS DEJA	
		$hostname = "$mysql_host";
		//echo $hostname;    
    	$user = $mysql_user;
		//echo $user;    
    	$password = $mysql_pwd;
		//echo $password;    
    	$bd = $mysql_db;
		
		$Langue = $Langue;
		//echo $bd;    
        // Name of the file
		
			if ($Langue == "English")
			{
				$filename = 'wordpresseng.sql';
			}
			else
			{
				$filename = 'wordpressfr.sql';
			}; 
			
		
				//$db = mysqli_connect('localhost','root','','envi_bd');
				$db = mysqli_connect($mysql_host,$mysql_user,$mysql_pwd,$mysql_db); 
				if (! $db) 
				{
					
					if ($Langue != "English")
						{
							exit('Echec de la connexion lors du vidage de la base de données.');
							$msg3 = "ERREUR LORS DU VIDAGE DE LA BASE DE DONNEES \r\n VERIFIEZ VOS DROITS SUR LA BASE DE DONNEES !"; 
							// or die(mysql_error()."Affichage des BD");
							return $msg3;
							exit;
						}
						else
						{
							exit('Failed to connect when emptying the database.');
							$msg3 = "ERROR WHEN DROPPING DATABASE \ r \ n CHECK YOUR RIGHTS ON THE DATABASE !"; 
							// or die(mysql_error()."Affichage des BD");
							return $msg3;
							exit;
						};
					
					
				}
				else
				{
					// ON IMPORTE LA BASE DE DONNEES
					// echo "resultat ".$res;
						// Temporary variable, used to store current query
						$templine = '';
						// Read in entire file
						$lines = file($filename);
						// Loop through each line
						foreach ($lines as $line)
						{
							// Skip it if it's a comment
							if (substr($line, 0, 2) == '--' || $line == '')
								continue;
							
							// Add this line to the current segment
							$templine .= $line;
							// If it has a semicolon at the end, it's the end of the query
							if (substr(trim($line), -1, 1) == ';')
							{
								// Perform the query
								/* $sqlDB_DROP = "DROP DATABASE $mysql_db"; 
								$okDB_DROP = mysqli_query($db,$sqlDB_DROP);
								mysqli_connect($mysql_host,$mysql_user,$mysql_pwd,$mysql_db);  */
								if (mysqli_query($db,$templine)) 
								{
									// Reset temp variable to empty
									$templine = '';
								}
								else
								{
									if ($Langue != "English")
										{
											$msg4 = "ERREUR LORS DE L'EXECUTION DE LA REQUETE : ".'<strong>' . $templine . '\': ' . mysql_error() . '<br /><br />'; 
											// or die(mysql_error()."Affichage des BD");
											return $msg4;
											exit;
										}
										else
										{
											$msg4 = "ERROR WHEN EXECUTING THE REQUEST : ".'<strong>' . $templine . '\': ' . mysql_error() . '<br /><br />'; 
											// or die(mysql_error()."Affichage des BD");
											return $msg4;
											exit;
											
										};
									
									
								}
								
							}
						}
						 
					if ($Langue != "English")
						{
							$msg5= "INSTALLATION DES PARAMETRES INITIAUX TERMINEES...VEUILLEZ PATIENTER... !";
							/* return $msg5;
							exit; */
						}
						else
						{
							$msg5= "INSTALLATION OF INITIAL PARAMETERS COMPLETED ... PLEASE WAIT ... !";
							/* return $msg5;
							exit; */
							
						};				
					
				}
		
		return $msg5;
		//exit;
		
} // FIN FONCTION IMPORT PACKAGE BD



// FONCTION MISE A JOUR DU FICHIER DE CONFIGURATION WORDPRESS $mysql_db $mysql_user  $mysql_pwd $mysql_host
function wordpress_config_file($mysql_db, $mysql_user,  $mysql_pwd, $mysql_host)
{	

		// SUPPRIMER L'ANCIEN FICHIER wp-config.php S'IL EXISTE
		if(file_exists("wp-config.php")){unlink('wp-config.php');}
		
		// COPIER LE FICHIER wp-config-sample.php ET LE RENOMMER EN wp-config.php
		copy("wp-config-samplefr.php", "wp-config.php"); 
		
		
		// 1 : Ouvre le fichier et retourne un tableau contenant une ligne par élément*/
		//$lines = file('wp-config.php');

		// 2 : on fera ici nos opérations sur le fichier...
		// On parcourt le tableau $lines et on affiche le contenu de chaque ligne précédée de son numéro*/
		/* foreach ($lines as $lineNumber => $lineContent)
		{
		   // 'i' : On remplace votre_nom_de_bdd par le nom de la BD
			$conf = str_replace("votre_nom_de_bdd", $mysql_db, $lineContent);
		   // 'ii' : On remplace votre_utilisateur_de_bdd par le nom d'utilisateur de la BD
			$conf = str_replace("votre_utilisateur_de_bdd", $mysql_user, $lineContent);
		   // 'iii' : On remplace votre_mdp_de_bdd par le mot de passe de la BD
			$conf = str_replace("votre_mdp_de_bdd", $mysql_pwd, $lineContent);
		   // 'iv' : On remplace localhost par le nom d'hote de MySQL
			$conf = str_replace("localhost", $mysql_host, $lineContent);
		} */
				
		
				//chmod 777 wp-config.php;
				/*Ouverture du fichier en lecture seule*/
				$fichier="wp-config.php";
				
				// PREMIERE LIGNE
				$handle = fopen($fichier, 'r+');
				/*Si on a réussi à ouvrir le fichier*/
				if ($handle)
				{
							/*On lit la ligne courante*/
							$buffer = file_get_contents($fichier);
							/*On l'affiche*/
							// 'i' : On remplace votre_nom_de_bdd par le nom de la BD
							$conf = str_replace("votre_nom_de_bdd", $mysql_db, $buffer);
							fwrite($handle,$conf); 

					/*On ferme le fichier*/
					fclose($handle);
				}
				
				// DEUXIEME LIGNE
				$handle = fopen($fichier, 'r+');
				/*Si on a réussi à ouvrir le fichier*/
				if ($handle)
				{
							/*On lit la ligne courante*/
							$buffer = file_get_contents($fichier);
							/*On l'affiche*/
							// 'i' : On remplace votre_nom_de_bdd par le nom de la BD
							$conf = str_replace("votre_utilisateur_de_bdd", $mysql_user, $buffer);
							fwrite($handle,$conf); 

					/*On ferme le fichier*/
					fclose($handle);
				}


				// TROISIEME LIGNE
				$handle = fopen($fichier, 'r+');
				/*Si on a réussi à ouvrir le fichier*/
				if ($handle)
				{
							/*On lit la ligne courante*/
							$buffer = file_get_contents($fichier);
							/*On l'affiche*/
							// 'i' : On remplace votre_nom_de_bdd par le nom de la BD
							$conf = str_replace("votre_mdp_de_bdd", $mysql_pwd, $buffer);
							fwrite($handle,$conf); 

					/*On ferme le fichier*/
					fclose($handle);
				}
				
				
				// QUATRIEME LIGNE
				$handle = fopen($fichier, 'r+');
				/*Si on a réussi à ouvrir le fichier*/
				if ($handle)
				{
							/*On lit la ligne courante*/
							$buffer = file_get_contents($fichier);
							/*On l'affiche*/
							// 'i' : On remplace votre_nom_de_bdd par le nom de la BD
							$conf = str_replace("localhost", $mysql_host, $buffer);
							fwrite($handle,$conf); 

					/*On ferme le fichier*/
					fclose($handle);
				}

					
} // FIN FONCTION MISE A JOUR DU FICHIER DE CONFIGURATION WORDPRESS



// FONCTION MISE A JOUR DU FICHIER DE CONFIGURATION WORDPRESS $mysql_db $mysql_user  $mysql_pwd $mysql_host
function wordpress_config_file_en($mysql_db, $mysql_user,  $mysql_pwd, $mysql_host)
{	

		// SUPPRIMER L'ANCIEN FICHIER wp-config.php S'IL EXISTE
		if(file_exists("wp-config.php")){unlink('wp-config.php');}
		
		// COPIER LE FICHIER wp-config-sample.php ET LE RENOMMER EN wp-config.php
		copy("wp-config-sample_en.php", "wp-config.php"); 
			
				
				//chmod 777 wp-config.php;
				/*Ouverture du fichier en lecture seule*/
				$fichier="wp-config.php";
				
				// PREMIERE LIGNE
				$handle = fopen($fichier, 'r+');
				/*Si on a réussi à ouvrir le fichier*/
				if ($handle)
				{
							/*On lit la ligne courante*/
							$buffer = file_get_contents($fichier);
							/*On l'affiche*/
							// 'i' : On remplace votre_nom_de_bdd par le nom de la BD
							$conf = str_replace("database_name_here", $mysql_db, $buffer);
							fwrite($handle,$conf); 

					/*On ferme le fichier*/
					fclose($handle);
				}
				
				// DEUXIEME LIGNE
				$handle = fopen($fichier, 'r+');
				/*Si on a réussi à ouvrir le fichier*/
				if ($handle)
				{
							/*On lit la ligne courante*/
							$buffer = file_get_contents($fichier);
							/*On l'affiche*/
							// 'i' : On remplace votre_nom_de_bdd par le nom de la BD
							$conf = str_replace("username_here", $mysql_user, $buffer);
							fwrite($handle,$conf); 

					/*On ferme le fichier*/
					fclose($handle);
				}


				// TROISIEME LIGNE
				$handle = fopen($fichier, 'r+');
				/*Si on a réussi à ouvrir le fichier*/
				if ($handle)
				{
							/*On lit la ligne courante*/
							$buffer = file_get_contents($fichier);
							/*On l'affiche*/
							// 'i' : On remplace votre_nom_de_bdd par le nom de la BD
							$conf = str_replace("password_here", $mysql_pwd, $buffer);
							fwrite($handle,$conf); 

					/*On ferme le fichier*/
					fclose($handle);
				}
				
				
				// QUATRIEME LIGNE
				$handle = fopen($fichier, 'r+');
				/*Si on a réussi à ouvrir le fichier*/
				if ($handle)
				{
							/*On lit la ligne courante*/
							$buffer = file_get_contents($fichier);
							/*On l'affiche*/
							// 'i' : On remplace votre_nom_de_bdd par le nom de la BD
							$conf = str_replace("localhost", $mysql_host, $buffer);
							fwrite($handle,$conf); 

					/*On ferme le fichier*/
					fclose($handle);
				}

					
} // FIN FONCTION MISE A JOUR DU FICHIER DE CONFIGURATION WORDPRESS ENGLISH




//  FONCTION VARIABLES DE SESSION ET URL
//wordpress_session_url($server_name, $dir_name)
function wordpress_session_url($server_name, $dir_name, $mysql_db, $mysql_user,  $mysql_pwd, $mysql_host, $Langue)
{	

		//CREER LA BASE DE DONNEES SI ELLE N'EXISTE PAS DEJA	
		$hostname = "$mysql_host";
		//echo $hostname;    
    	$user = $mysql_user;
		//echo $user;    
    	$password = $mysql_pwd;
		//echo $password;    
    	$bd = $mysql_db;
		//echo $bd;    
		
		$Langue = $Langue;
		
		
				//$db = mysqli_connect('localhost','root','','envi_bd');
				$db = mysqli_connect($mysql_host,$mysql_user,$mysql_pwd,$mysql_db); 
				if (! $db) 
				{

					//echo $bd;    
					// Name of the file
					
						if ($Langue == "English")
						{
							//exit('Echec de la connexion lors du vidage de la base de données.');
							$msg3 = "ERROR WHEN CONNECTING TO DATABASE, CHECK YOUR RIGHTS ON THE DATABASE !"; 
							// or die(mysql_error()."Affichage des BD");
						}
						else
						{
							//exit('Echec de la connexion lors du vidage de la base de données.');
							$msg3 = "ERREUR LORS DE LA CONNEXION A LA BASE DE DONNEES, VERIFIEZ VOS DROITS SUR LA BASE DE DONNEES !"; 
							// or die(mysql_error()."Affichage des BD");
						}; 
					return $msg3;
					exit;
					
				}
				else
				{
					//$url_finale='/'.$url_dossier.'/wp-login.php';
					$url_session='http://' .$server_name .'/'.$dir_name;
					
					/// Modification du siteurl
					$sqlDB_UPDATE ="UPDATE `wp_options` SET `option_value` = '".$url_session."' WHERE `option_id` = 1";
					$okDB_UPDATE = mysqli_query($db,$sqlDB_UPDATE);
					
					/// Modification du home
					$sqlDB_UPDATE ="UPDATE `wp_options` SET `option_value` = '".$url_session."' WHERE `option_id` = 2";
					$okDB_UPDATE = mysqli_query($db,$sqlDB_UPDATE);
					
					/// MODIFICATION du UID `wp_posts`
					// 1ère ligne
					$url_guid='http://' .$server_name .'/'.$dir_name.'/?p=1';
					$sqlDB_UPDATE ="UPDATE `wp_posts` SET `guid` = '".$url_guid."' WHERE `ID` = 1";
					$okDB_UPDATE = mysqli_query($db,$sqlDB_UPDATE);
					
					// 2ème ligne
					$url_guid='http://' .$server_name .'/'.$dir_name.'/?p=2';
					$sqlDB_UPDATE ="UPDATE `wp_posts` SET `guid` = '".$url_guid."' WHERE `ID` = 2";
					$okDB_UPDATE = mysqli_query($db,$sqlDB_UPDATE);
					
					// 3ème ligne
					$url_guid='http://' .$server_name .'/'.$dir_name.'/?p=3';
					$sqlDB_UPDATE ="UPDATE `wp_posts` SET `guid` = '".$url_guid."' WHERE `ID` = 3";
					$okDB_UPDATE = mysqli_query($db,$sqlDB_UPDATE);
				}
					
} // FIN FONCTION VARIABLES DE SESSION ET URL




//////////////////////////////////////////////////////////////////////////////////
/////////////////// CONTROLES SUR LES CHAMPS /////////////////////////////////////
//Réinitialiser la taille du tableau $msg   $mysql_db $mysql_user  $mysql_pwd $mysql_host
$msg = array();
$erreurs = array();
$control1="";
$control2="";
$control3="";
if (empty($frm['mysql_db']) ) 
	{
			$erreurs['mysql_db'] = true;
			if ($Langue != "English")
			{
				$control1= "<p style=\"text-align:center\">".nl2br("<span style=\"color:red\">".htmlentities("Base de données MySQL",ENT_QUOTES,'UTF-8')."</span>")."</p>";
				//echo nl2br("<span style=\"color:red\">".$msg['RaisonSociale']."</span>") ;
			}
			else
			{
				$control1= "<p style=\"text-align:center\">".nl2br("<span style=\"color:red\">".htmlentities("MySQL Database name",ENT_QUOTES,'UTF-8')."</span>")."</p>";
				//echo nl2br("<span style=\"color:red\">".$msg['RaisonSociale']."</span>") ;
			};
			
			
	};


if (empty($frm['mysql_user']) ) 
	{
			$erreurs['mysql_user'] = true;
			if ($Langue != "English")
			{
				$control2= "<p style=\"text-align:center\">".nl2br("<span style=\"color:red\">".htmlentities("Utilisateur MySQL",ENT_QUOTES,'UTF-8')."</span>")."</p>";
				//echo nl2br("<span style=\"color:red\">".$msg['RaisonSociale']."</span>") ;
			}
			else
			{
				$control2= "<p style=\"text-align:center\">".nl2br("<span style=\"color:red\">".htmlentities("MySQL username",ENT_QUOTES,'UTF-8')."</span>")."</p>";
				//echo nl2br("<span style=\"color:red\">".$msg['RaisonSociale']."</span>") ;
			};
			
			
	};


if (empty($frm['mysql_host']) ) 
	{
			$erreurs['mysql_host'] = true;
			if ($Langue != "English")
			{
				$control3= "<p style=\"text-align:center\">".nl2br("<span style=\"color:red\">".htmlentities("Hôte MySQL",ENT_QUOTES,'UTF-8')."</span>")."</p>";
				//echo nl2br("<span style=\"color:red\">".$msg['RaisonSociale']."</span>") ;
			}
			else
			{
				$control3= "<p style=\"text-align:center\">".nl2br("<span style=\"color:red\">".htmlentities("MySQL host",ENT_QUOTES,'UTF-8')."</span>")."</p>";
				//echo nl2br("<span style=\"color:red\">".$msg['RaisonSociale']."</span>") ;
			};
					
	};

$retour="<p style=\"text-align:center\"><a href=http://localhost/wordpress/wordpress-install.php>"."<span style=\"color:red\">"."RETOUR AU FORMULAIRE..."."</span>"."</a></p>"; 

//echo "jc";
if (sizeof($erreurs) > 0) 
{
	
	if ($Langue != "English")
	{
		echo "<p style=\"text-align:center\">".nl2br("<span style=\"color:red\">"."LES CHAMPS CI-DESSOUS SONT VIDES, VEUILLEZ LES RENSEIGNER : ".$control1.$control2.$control3."</span>"."</p>"); 
		//return $Langue;
	} 
	else 
	{
		echo "<p style=\"text-align:center\">".nl2br("<span style=\"color:red\">"."THESES FIELDS ARE EMPTY, PLEASE FILL THEM : ".$control1.$control2.$control3."</span>"."</p>"); 
	
			
	};
	
	//echo "<p style=\"text-align:center\">".nl2br("<span style=\"color:red\">"."LES CHAMPS CI-DESSOUS SONT VIDES, VEUILLEZ LES RENSEIGNER : ".$control1.$control2.$control3."</span>"."</p>"); 
	
};
/////////////////// FIN CONTROLES SUR LES CHAMPS /////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////////
//////////////S'IL N'Y A PAS D'ERREUR ON PEUT TRAITER LE FORMULAIRE////////////////
///////////////////////////////////////////////////////////////////////////////////
//echo sizeof($msg);

if (sizeof($erreurs)== 0) // 
{

	//GESTION DES DIVERS TRAITEMENTS
		//$db = mysqli_connect('mysql.hostinger.fr','u954573208_did','minesudd','u954573208_envi'); 
		/* $db = mysqli_connect('$mysql_host','$mysql_user','$mysql_pwd','$mysql_db'); 
		if (! $db) {
		exit('Echec de la connexion lors du traitement.');
		} */
		//Vérification et création de la BD s'il est inexistante
		//echo $mysql_db.$mysql_user.$mysql_pwd.$mysql_host."  --->  "; 
		
		echo '<script type="text/javascript">'
				 .'return document.getElementById(\'chargement\').style.display=\'none\';'
				 .'return document.getElementById(\'site\').style.visibility=\'visible\';'
			     . '</script>'; 
				 
		$resultat="";		 
		$resultat=verif_creation_bd_mysql($mysql_db, $mysql_user,  $mysql_pwd, $mysql_host, $Langue);
		if ($resultat !="") 
		{
			echo "<p style=\"text-align:center\">".nl2br("<span style=\"color:red\">".$resultat."</span>")."</p>"; 
			exit;
		};
		
		
		
		$import=import_package_bd_mysql($mysql_db, $mysql_user, $mysql_pwd, $mysql_host, $Langue);
		//echo "<p style=\"text-align:center\">".nl2br("<span style=\"color:white;font-weight:bold;font-size:22px;background-color: #14358D;background-image:linear-gradient(white, #14358D);background-image:radial-gradient(white, #14358D);height: 30px \">".$import."</span>")."</p>"; 
		//echo '<script type="text/javascript">'
		//		 .'return document.getElementById(\'chargement_alerte\').style.display=\'none\';'
		//		 .'return document.getElementById(\'site_alerte\').style.visibility=\'visible\';'
		//	     . '</script>'; 
					$nextTime = time() + (1 * 1 * 1 * 15);
					// 0 jours; 00 heures; 00 minutes; 15 secondes
					//echo 'Date prochaine1 : '. date('Y-m-d H:i:s', $nextTime) ."\n";
					// ou en utilisant strtotime():
					//echo 'Date prochaine2 : '. date('Y-m-d H:i:s', strtotime('+15 second')) ."\n";

					$date = date('Y-m-d H:i:s', strtotime('+1 second'));//date de la variable
					$jour = substr($date,8,2); // on récupère le jour
					$mois = substr($date,5,2); // puis le mois
					$annee = substr($date,0,4); // et l'annee
					$heure = substr($date,11,2); // et l'HEURE
					$minute = substr($date,14,2); // et MINUTES
					$seconde = substr($date,17,2); // et MINUTES
					$timestamp = mktime($heure,$minute,$seconde,$mois,$jour,$annee); 

					$presentement = time(); //heure actuelle
					$ecart_secondes = $timestamp-$presentement;  
					$ecart_jours = floor($ecart_secondes / (60*60*24));
					$ecart_heure = floor(($ecart_secondes - ($ecart_jours * 86400)) /(60*60));
					$ecart_minute =floor(($ecart_secondes - ($ecart_jours * 86400) - ($ecart_heure * 3600)) / 60);

					//echo 'Ecart en secondes : '.$ecart_secondes."\n";
			$test = 1;
			$datelimite = $timestamp;
			while ($test < 10)
			{
				
				if ($Langue == "English")
					{
						$illu = "---> Step ".$test."/10";
					}
					else
					{
						$illu = "---> Etape ".$test."/10";
					};
				
				echo "<p style=\"text-align:center\">".nl2br("<span style=\"color:white;font-weight:bold;font-size:22px;background-color: #f60;background-image:linear-gradient(white, #f60);background-image:radial-gradient(white, #f60);height: 40px \">".$import.$illu."</span>")."</p>"; 
			   
			   /* if(($datelimite-time())>=0)
			    { 
					$test = 1;
		   		}
				else
				{
					$test = 0;
				}; */
				/* $presentement = time();
				$test = $test ; */
				$test += 1;
			}
		
		// Stoppe pour 2 secondes
		// Retourne false et génère une alerte
		/* var_dump(time_sleep_until(time()-1));
		var_dump(time_sleep_until(microtime(true)+10));
		usleep(5000000); */
		
		sleep(2); // attends 5 secondes 
		
			if ($Langue == "English")
			{
				wordpress_config_file_en($mysql_db, $mysql_user, $mysql_pwd, $mysql_host); 
			}
			else
			{
				wordpress_config_file($mysql_db, $mysql_user, $mysql_pwd, $mysql_host); 
			};
		
		//wordpress_config_file($mysql_db, $mysql_user, $mysql_pwd, $mysql_host); 
		//wordpress_config_file_en($mysql_db, $mysql_user, $mysql_pwd, $mysql_host); 
		//echo "<p style=\"text-align:center\">".nl2br("<span style=\"color:red\">"."CONFIGURATION TERMINEE"."</span>")."</p>"; 
		
		// ATTENTE DE 3 SECONDES
		sleep(1); // attends 3 secondes
		
		
		/*header("Location: /wp-login.php",TRUE,301);
		exit;
		header("Location: http://localhost/wordpresseng/wp-login.php/");
		 Redirection vers une page différente du même dossier 
		$host  = $_SERVER['HTTP_HOST'];
		$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
		$extra = 'wp-login.php';
		header("Location: http://$host$uri/$extra");
		exit;*/
		//////////////////////////////////////////////////////////////////////////////
		//////////// REDIRIGER VERS LA PAGE D'INSTALLATION WORDPRESS//////////////////
		
		//sleep(5); // attends 3 secondes   '.$dossier_install.'
		//header('Location: ./wp-admin/install.php'); // redirige vers cible.php (indiquer le bon chemin relatif !)
		//header('Location: ./wp-admin/install.php');
		//echo "<p style=\"text-align:center\">".'http://' . $_SERVER['SERVER_NAME'] . '/' . $_GET['mod']."</p>"; 
		$url = $_SERVER['SERVER_NAME'] . $_SERVER['PHP_SELF'];
		$url_list = explode('/', $url);
		$url_dossier = $url_list[1]; // affiche: premierDossier
		$url = $_SERVER['SERVER_NAME'] . '/' .$url_dossier ;
        //echo "<p style=\"text-align:center\">".nl2br("<span style=\"color:red\">".$url."</span>")."</p>"; 
		
		//////////  Changement des options siteurl et home dans la BD ///////////
		$session_wordp ="";
		$session_wordp=wordpress_session_url($_SERVER['SERVER_NAME'], $url_dossier, $mysql_db, $mysql_user,  $mysql_pwd, $mysql_host, $Langue);
		if ($session_wordp !="") 
		{
			echo "<p style=\"text-align:center\">".nl2br("<span style=\"color:red\">".$session_wordp."</span>")."</p>"; 
			exit;
		};
		
		$url_finale='/'.$url_dossier.'/wp-login.php';
		$url_finale='http://' .$_SERVER['SERVER_NAME'] .$url_finale;
		//header('Location: '.$url_finale);
		echo "<script type='text/javascript'>document.location.replace('$url_finale');</script>";
		// http://localhost/wordpresseng/wp-login.php

} 
///////////////////////////////////////////////////////////////////////////////////
/////////////////////////////FIN PAS D'ERREUR FORMULAIRE///////////////////////////
///////////////////////////////////////////////////////////////////////////////////
 
}

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<link rel="stylesheet" type="text/css" href="./wordpress-install.css" media="all" />
	
	<script src="assets/jquery/jquery-1.10.2.min.js"></script>
	<link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<script src="assets/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/prettify/run_prettify.js"></script>
	<link href="assets/bootstrap-dialog/css/bootstrap-dialog.min.css" rel="stylesheet" type="text/css" />
	<script src="assets/bootstrap-dialog/js/bootstrap-dialog.min.js"></script>
	
	<title>Installation de Wordpress en une seule étape</title>
	
	<!--[if IE]>
	<style type="text/css" media="all">.borderitem {border-style: solid;}</style>
	<![endif]--> 
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<style type="text/css">td img {display: block;}</style>
	<!--Fireworks CS6 Dreamweaver CS6 target.  Created Sat Aug 23 15:26:03 GMT+0000 (Greenwich) 2014-->
	<style>
		.login-dialog .modal-dialog {
			width: 300px;
		}
	</style>
</head>

<body onload= "Optionclic();">
<div class="source-code runnable">
        <!--
        BootstrapDialog.show({
            message: 'Hi Apple!'
        });
        -->
</div>

<form action="wordpress-install.php" onSubmit="return ConfirmationBootstrap4();" id="form1" name="form1" method="post" enctype="application/x-www-form-urlencoded" autocomplete="off">


<div id="Div">

<div align="center" id="chargement" style="width:690px;height:50px;position:absolute;z-index:1;top:0;margin-left: auto;margin-right: auto; color:red;font-weight:bold;font-size:22px;background:transparent; visibility:hidden;">
   <img id="tonanimation" name="image" src="tonanimation.gif" /> <br><br><p id="libelle_traitement"> TRAITEMENT EN COURS ... VEUILLEZ PATIENTER !</p>
</div>

<div id="site" >


<div class="Txt_WORDPRESS">
	
		<p class="lastNode">WORDPRESS
	</p>
</div>
<div class="Txt_ETAPE">
	
		<p id="libelle_etape" class="lastNode">ETAPE UNIQUE D&rsquo;INSTALLATION: <br />PARAMETRAGE DE LA BASE DE DONNEES
	</p>
</div>
<div id="Div2">
</div>
<div id="Div3">
</div>
<div class="Txt_Langue">
	
		<p id="libelle_langue" class="lastNode">Langue d&rsquo;installation : 
	</p>
</div>
<!--<div id="languediv" onclick="RefreshIframe();">-->
<!--<select name="Langue" id="Langue" onchange="language_conv();" ><option onclick="language_conv();"><a onclick="language_conv();"><?php //echo htmlentities("Français",ENT_QUOTES,'UTF-8'); ?></a></option><option onclick="language_conv();"><?php //echo htmlentities("English",ENT_QUOTES,'UTF-8'); ?> </option></select>-->

<select name="Langue" id="Langue" onchange="language_conv();" ><option value= "Français"><?php echo htmlentities("Français",ENT_QUOTES,'UTF-8'); ?></option><option value= "English"><?php echo htmlentities("English",ENT_QUOTES,'UTF-8'); ?> </option></select>
<!--</div>-->
<div id="Div4">
</div>
<div class="Txt_Nom">
	
		<p id="libelle_bd" class="lastNode"><?php echo htmlentities("Nom de la base données : ",ENT_QUOTES,'UTF-8'); ?>
	</p>
</div>
<input type="text" name="mysql_db" id="mysql_db" placeholder ="wordpress" value="<?php 	if (!empty($_POST["mysql_db"])) { // Le nom de la BD a été saisi --> le réafficher 		
			echo htmlentities($_POST["mysql_db"],ENT_QUOTES,'UTF-8'); }; if (!empty($hostnamejc)) {echo htmlentities($bdjc,ENT_QUOTES,'UTF-8'); };?>" /> 
<div id="Div5">
</div>
<div class="Txt_Utilisateur">
	
		<p id="libelle_user" class="lastNode">Utilisateur MySQL : 
	</p>
</div>

<div align="center" id="chargement_alerte" style="width:690px;height:50px;position:absolute;z-index:20;top:0;margin-left: auto;margin-right: auto; color:red;font-weight:bold;font-size:22px;background:transparent; visibility:hidden;">
   <img id="tonanimation" name="image" src="" /> <br><br><p id="libelle_alerte"> TRAITEMENT EN COURS ... VEUILLEZ PATIENTER !</p>
</div>
<div id="site_alerte" >
<input type="text" name="mysql_user" id="mysql_user" placeholder ="root" value="<?php 	if (!empty($_POST["mysql_user"])) { // Le nom de la BD a été saisi --> le réafficher 		
			echo htmlentities($_POST["mysql_user"],ENT_QUOTES,'UTF-8'); }; if (!empty($userjc)) {echo htmlentities($userjc,ENT_QUOTES,'UTF-8'); }; ?>" />
<div id="Div6">
</div>
<div class="Txt_Mot">
	
		<p id="libelle_pass" class="lastNode">Mot de passe MySQL : 
	</p>
</div>
<input type="text" name="mysql_pwd" id="mysql_pwd" placeholder ="pwd" value="<?php 	if (!empty($_POST["mysql_pwd"])) { // Le nom de la BD a été saisi --> le réafficher 		
			echo htmlentities($_POST["mysql_pwd"],ENT_QUOTES,'UTF-8'); }; if (!empty($passwordjc)) {echo htmlentities($passwordjc,ENT_QUOTES,'UTF-8'); }; ?>" />
<div id="Div7">
</div>
<div class="Txt_Nom2">
	
		<p id="libelle_host" class="lastNode">Nom de l&#8217;h&ocirc;te MySQL : 
	</p>
</div>
<input type="text" name="mysql_host" id="mysql_host" placeholder ="localhost" value="<?php 	if (!empty($_POST["mysql_host"])) { // Le nom de la BD a été saisi --> le réafficher 		
			echo htmlentities($_POST["mysql_host"],ENT_QUOTES,'UTF-8'); }; if (!empty($hostnamejc)) {echo htmlentities($hostnamejc,ENT_QUOTES,'UTF-8'); }; ?>" />
<img src="images/wordpress-install_r2_c2.gif" id="wordpress-install_r2_c2" alt="" />
<img src="images/wordpress-install_r2_c9.gif" id="wordpress-install_r2_c9" alt="" />
<img src="images/wordpress-install_r8_c10.gif" id="wordpress-install_r8_c10" alt="" />
<img src="images/wordpress-install_r10_c3.gif" id="wordpress-install_r10_c3" alt="" />
<input type="submit" name="bouton_valider" id="bouton_valider" value="VALIDER" />
</div>
</form>
</body>
</html>
