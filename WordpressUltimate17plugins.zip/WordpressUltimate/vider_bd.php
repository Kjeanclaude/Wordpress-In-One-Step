<?php 
		//bd=$mysql_db&host=$mysql_host&user=$mysql_user&pwd=$mysql_pwd"
		$mysql_db= $_POST['bd'];	
		$mysql_host= $_POST['host'];	
		$mysql_user= $_POST['user'];	
		$mysql_pwd= $_POST['pwd'];			
				
		$db = mysqli_connect($mysql_host,$mysql_user,$mysql_pwd,$mysql_db); 
				if (! $db) {
					exit('Echec de la connexion lors du vidage de la base de données.');
				}
				else
				{	
		$sqlDB_DROP = "DROP DATABASE $mysql_db"; 
		$okDB_DROP = mysqli_query($db,$sqlDB_DROP);
					
		/* $sqlDB_CREATE = "CREATE DATABASE $mysql_db"; 
		$okDB_CREATE = mysqli_query($db,$sqlDB_CREATE); */
				}

?>